import java.util.*;

class FCFS1 {
	public static void main(String args[]) {
		int i,j,n,temp;
		int total=0;
		Scanner input = new Scanner(System.in)	;
		System.out.println("Enter number of process");
		n=input.nextInt();
		int pid[]=new int[n];
		int art[]=new int[n];
		int bt[]=new int[n];
		int ct[]=new int[n];
		int ta[]=new int[n];
		int wt[]=new int[n];
		for ( i = 0; i< n; i++) {
			System.out.printf("Enter process P%d Arrival time:",i+1);
			art[i]=input.nextInt();
			System.out.printf("Enter process P%d Burst time:",i+1);
			bt[i]=input.nextInt();
			pid[i]=i+1;
		}
		for ( i = 0; i < n; i++) {
			for ( j = i+1; j < n; j++) {
				if(art[i]>art[j]){
					temp=art[i];
					art[i]=art[j];
					art[j]=temp;
					temp=bt[i];
					bt[i]=bt[j];
					bt[j]=temp;
					temp=pid[i];
					pid[i]=pid[j];
					pid[j]=temp;
				}
			}
		}
		for ( i = 0; i < n; i++) {
				if (i==0) {
					ct[i]=art[i]+bt[i];
					ta[i]=ct[i]-art[i];
					wt[i]=ta[i]-bt[i];
					total+=bt[i];
				}
				else if(i>0 && i<n){
					if(art[i]<ct[i-1]){
						ct[i]=total+bt[i];
						ta[i]=ct[i]-art[i];
						wt[i]=ta[i]-bt[i];
						total+=bt[i];
					}
					else{
						total=art[i];
						ct[i]=total+bt[i];
						ta[i]=ct[i]-art[i];
						wt[i]=ta[i]-bt[i];
						total+=bt[i];
					}
				}
			
		}

		System.out.printf("Pid\tarrival\tburst\tcompletion\tturnaround\twaiting\n"); 
		float avg_turn=0,avg_waiting=0;
		for(i=0;i<n;i++){
			System.out.println("p"+pid[i]+"\t"+art[i]+"\t"+bt[i]+"\t"+ct[i]+"\t\t"+ta[i]+"\t\t"+wt[i]);
			avg_turn=avg_turn+ta[i];
			avg_waiting=avg_waiting+wt[i];
		}
		System.out.println("Average Turnaround time="+avg_turn/n);
		System.out.println("Average Waiting time="+avg_waiting/n);
	}
}
