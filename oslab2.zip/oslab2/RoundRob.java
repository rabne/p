import java.util.*;
public class RoundRob{
	public static void main(String args[]){
		Queueee quee=new Queueee();
		quee.roundRob();
	}
}
class Node{
	int process;
	int arrival;
	int atime;
	int burst;
	int btime;
	int complete;
	int turnaround;
	int waiting;
	boolean flag;
	Node(int arv,int burst,int i){
		this.process=i;
		this.arrival=arv;
		this.atime=arv;
		this.burst=burst;
		this.btime=burst;		
		this.flag=false;
	}
}
class Process{
	Node pros;
	Process next;
	Process(Node pros){
		this.pros=pros;
	}
	Process(){
		
	}
	public Process insertNode(Process head,Node node){
		Process curr=head;
		Process temp=new Process(node);
		if(curr == null)
		{	
			return temp;
		}
		if(curr.next == null )
		{	
			curr.next=temp;
			return head;
		}
		while(curr.next != null){
			curr=curr.next;
		}
		curr.next=temp;
		return head;
	}
	public static Process deleteNode(Process head,Node node){
		Process curr=head;
		Process prev=head;
		if(curr == null){
			System.out.println("No Node matched to delete");
			return null;	
		}
		if(curr.next == null && curr.pros == node)
			return null;
		if(curr.next != null && curr.pros == node)
			return curr.next;
		while(curr.next != null && curr.pros != node){
			prev=curr;
			curr=curr.next;
		}
		if(curr == null)
		{
			System.out.println("No nodes matched");
			return head;
		}
		prev.next=curr.next;
		return head;
	}
}
class Queueee{
	int idel=0;
	int cputime=0;
	float avgwaiting=0;
	float avgturnaround=0;
	public void roundRob(){
		Queue<Node> que=new LinkedList<Node>();
		Scanner sc=new Scanner(System.in);
		int n,arv,burst;
		System.out.println("Enter no of process:");
		n=sc.nextInt();
		int tQuantum;
		System.out.println("Enter the time queantum:");
		tQuantum=sc.nextInt();
		Process head=null;
		int b=0;
		boolean m=false;
		for(int i=0;i < n;i++){
			System.out.println("Enter Process "+(i+1)+" Arrival and burst time");
			arv=sc.nextInt();
			burst=sc.nextInt();
			Node node=new Node(arv,burst,i+1);
			Process obj=new Process();
			head=obj.insertNode(head,node);
		}
		Process curr;
		Node mode=null;
		boolean True=false;
		int min=999;
		System.out.println("process | Arrival | Burst | Completion Time | Turn Around | Waiting |");
		while(head != null)
		{
			curr=head;
			True=false;
			while(curr != null){
				if(curr.pros.arrival <= cputime && curr.pros.flag == false){
						que.add(curr.pros);
						curr.pros.flag=true;
						curr=curr.next;
						True=true;
				}
				else
				{	if(min > curr.pros.arrival)
						min=curr.pros.arrival;
					curr=curr.next;
			
				}	
			}
			if(True)
			{
				if( m == true && mode.burst != 0 )
				{
					que.poll();
					que.add(mode);
				}
				if(m == true && mode.burst == 0){
					avgturnaround += (float)mode.turnaround;
					avgwaiting += (float)mode.waiting;
					System.out.println(mode.process+"          "+mode.atime+"         "+mode.btime+"            "+mode.complete+"          "+mode.turnaround+"           "+mode.waiting );
					head=Process.deleteNode(head,mode);
					que.poll();
				}
				if(que.isEmpty() == false){
					mode=que.peek();
					b=cpu.roundCpu(mode,tQuantum,cputime);
					m=true;
					cputime +=b;	
				}
			}
			else
				cputime+=min;		
		}
		System.out.println("average turnaround time: "+avgturnaround/n);
		System.out.println("average waiting time: "+avgwaiting/n);
	}
}
class cpu{
	public static int roundCpu(Node node,int tQuantum,int cputime){
		int cpuused=0;
		if(node.burst > tQuantum){
			cputime += tQuantum;
			node.burst -= tQuantum;
			return tQuantum;
		}
		else if(node.burst == tQuantum){
			cputime += tQuantum;
			node.burst -= tQuantum;
			node.complete= cputime;
			node.turnaround=node.complete - node.atime;
			node.waiting = node.turnaround-node.btime;
			return tQuantum;
		}
		else{
			cputime += node.burst;
			cpuused=node.burst;
			node.burst -= node.burst;
			node.complete=cputime;
			node.turnaround=node.complete - node.atime;
			node.waiting=node.turnaround - node.btime;
			return cpuused;
		}
	}
}











