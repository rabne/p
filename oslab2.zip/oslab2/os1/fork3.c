#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>
#include<sys/types.h>
main()
{
	int id;
	printf("process id= %d",getpid());
	id=fork();
	if(id>0)
	{
		printf("Hello!I'm parent process with an ID:%d\n",getpid());
		printf("process that was created with ID:%d\n",id);
	}
	else if(id==0)
	{
		printf("hello!I'm child process with an ID:%d\n",getpid());
		printf("My parent process with an ID:%d\n",getppid());
	}
	else
	{
		printf("no process created");
	}
}
/*process id= 12137Hello!I'm parent process with an ID:12137
process that was created with ID:12138
process id= 12137hello!I'm child process with an ID:12138
My parent process with an ID:12137
*/
