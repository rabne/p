#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>
#include<sys/types.h>
main()
{
	int id,i;
	id=fork();
	for(i=0;i<15;i++)
	{
		printf("Hello!I'm parent process with an ID:%d\n",getpid());
	}
	for(i=0;i<15;i++)
	{
		printf("hello!I'm child process with an ID:%d\n",getpid());
	}
}

