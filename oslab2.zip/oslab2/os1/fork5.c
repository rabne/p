#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>
#include<sys/types.h>
main()
{
	int id,i;
	id=fork();
     if(id>0)
     {
        sleep(30);
     	//wait(NULL);
	for(i=0;i<4;i++)
	{
		printf("Hello!I'm parent process with an ID:%d\n",getpid());
	}
     }
     else if(id==0)
     {
	for(i=0;i<4;i++)
	{
		printf("hello!I'm child process with an ID:%d\n",getpid());
	}
     }
}

