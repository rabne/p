#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>
#include<sys/types.h>
main()
{
    int fd,fd1;
    char store[30];
    fd=creat("first",S_IRWXU);
    printf("%d",fd);
    fd1=open("second",O_CREAT|O_RDWR,S_IRWXU);
    printf("%d",fd1);
    open("first",O_RDWR);
    read(0,store,5);
    write(fd,store,5);
    lseek(fd,1,SEEK_SET);
    write(fd,store,5);
    close(fd);
}
