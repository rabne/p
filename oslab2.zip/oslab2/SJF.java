import java.util.*;
class SJF{
public static void main(String args[]){
	int arr[];
	int i,n,j,starting_time=0,total=0;
	Scanner input=new Scanner(System.in);
	System.out.println("enter number of process");
	n=input.nextInt();
	int pid[]=new int[n];
	int art[]=new int[n];
	int bt[]=new int[n];
	int ct[]=new int[n];
	int ta[]=new int[n];
	int wt[]=new int[n];
	int f[]=new int[n];
	for(i=0;i<n;i++){
	System.out.printf("enter process p%d Arrival time:",i+1);
	art[i]=input.nextInt();
	System.out.printf("enter process p%d Burst time:",i+1);
	bt[i]=input.nextInt();
	pid[i]=i+1;
	f[i]=0;
	}
	while(true){
		int c=n,min=999999;
		if(total==n)
			break;
		for(i=0;i<n;i++){
			if((art[i]<=starting_time)&&(f[i]==0)&&(bt[i]<min))
			{
				min=bt[i];
				c=i;
			}
		}
		if(c==n)
		starting_time++;
		else{
			ct[c]=starting_time+bt[c];
			starting_time+=bt[c];
			ta[c]=ct[c]-art[c];
			wt[c]=ta[c]-bt[c];
			f[c]=1;
			pid[total]=c+1;
			total++;
		}
	}
	System.out.printf("pid\tarrival\tburst\tcompletion\tturn\twait\n"); 	
	float avg_turn=0,avg_waiting=0;
	for(i=0;i<n;i++){
		System.out.println("p"+pid[i]+"\t"+art[i]+"\t"+bt[i]+"\t"+ct[i]+"\t\t"+ta[i]+"\t"+wt[i]);
		avg_turn=avg_turn+ta[i];
		avg_waiting=avg_waiting+wt[i];
		}
	System.out.println("Avg Turn around time="+avg_turn/n+" milliseconds");
	System.out.println("Avg Waiting time="+avg_waiting/n+" milliseconds");	
	
	
}
}
