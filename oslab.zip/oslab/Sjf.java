import java.util.*;
public class Sjf{
	public static void main(String args[]){
		Queuee qu=new Queuee();
		qu.userQueue();
	}
}
class Node{
	int process;
	int arrival;
	int burst;
	int complete;
	int turnaround;
	int waiting;
	Node next;
	Node(int arrival,int burst,int process){
		this.arrival=arrival;
		this.burst=burst;
		this.process=process;
	}
}
class Process{
	Node pros;
	Process next;
	Process(Node pros)
	{
		this.pros=pros;
	}
	Process()
	{
	
	}
	public static Process insert(Process head,Node p){
		Process curr=head;
		Process temp=new Process(p);
		if(curr == null)
		{	
			return temp;
		}
		if(curr.next == null)
		{	
			curr.next=temp;
			return head;
		}
		while(curr.next != null){
			curr=curr.next;
		}
		curr.next=temp;
		return head;
	}
	public static Process deleteProcess(Process head,Node pro){
		Process curr=head;
		Process prev=head;
		if(curr == null)
		{
			System.out.println("No nodes to delete");
			return null;
		}
		if(curr.next == null && curr.pros == pro)
			return null;
		if(curr.next != null && curr.pros == pro)
		{
				return curr.next;
		}
		while(curr != null && curr.pros != pro){
			prev=curr;
			curr=curr.next;
		}
		if(curr == null)
		{	System.out.println("No node matched to delete");
			return head;
		}
		prev.next=curr.next;
		return head;
	}
}
class Queuee{
	int cputime=0;
	float avgturnaround=0;
	float avgwaiting=0;
	Queue<Node> que=new LinkedList<Node>();
	public void userQueue(){
		Scanner sc=new Scanner(System.in);
		System.out.println("ENter no of processes:");
		int n=sc.nextInt();
		Process head=null;
		for(int i=0; i< n ;i++){
			System.out.println("ENter process "+(i+1)+" Arrival time and burst time");
			int arr=sc.nextInt();
			int burst=sc.nextInt();
			Node obj=new Node(arr,burst,i+1);
			Process pobj=new Process();
			head=pobj.insert(head,obj);
		}
		Process curr=head;
		cpu obj=null;
		boolean True=false;
		int min=999;
		System.out.println("process | Arrival | Burst | Completion Time | Turn Around | Waiting |");
		while(head != null){
			curr=head;
			True=false;
			while(curr != null){
				if(curr.pros.arrival <= cputime){
					True=true;
					que.add(curr.pros);
					curr=curr.next;
				}
				else
				{	if(min > curr.pros.arrival)
						min=curr.pros.arrival;
					curr=curr.next;
					break;
				}	
			}
			if(True){
				Node node=ReadyQueue.ready(que,head);
				obj=new cpu();
				obj.find(node,n,cputime);
				cputime += node.burst;
				avgturnaround+=(float)node.turnaround;
				avgwaiting+=(float)node.waiting;
				System.out.println(node.process+"          "+node.arrival+"         "+node.burst+"            "+node.complete+"          "+node.turnaround+"           "+node.waiting );
				head=Process.deleteProcess(head,node);
			}
			else
				cputime += min;
				
		}
		System.out.println("average turnaround time: "+avgturnaround/n);
		System.out.println("average waiting time: "+avgwaiting/n);
	}
}
class ReadyQueue{
	public static Node ready(Queue que,Process head){
		Deque<Node> rqu=new ArrayDeque<Node>();
		Process curr=head;
		while(que.isEmpty() == false){
			if(rqu.isEmpty())
			{	
				rqu.addFirst((Node)que.remove());
			}
			else if(((Node)que.element()).burst < rqu.getFirst().burst)
			{	
				rqu.addFirst((Node)que.remove());
				
			}	
			else
			{	
				rqu.addLast((Node)que.remove());
			}

		}
		return rqu.removeFirst();
	}
}
class cpu{
	public void find(Node node,int n,int cputime){
		cputime+=node.burst;
		node.complete=cputime;
		node.turnaround=node.complete-node.arrival;
		node.waiting=node.turnaround-node.burst;
	}
}
