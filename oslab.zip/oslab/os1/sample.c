#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>
#include<sys/types.h>
int main(){
	int fd,fd1;
	id=fork();
	printf("welcome to sample.txt");
	printf("process ID=%d parent ID parent ID=%d",getpid(),getppid());
	exit(EXIT_SUCCESS);
}
