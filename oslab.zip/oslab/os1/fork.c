#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>
#include<sys/types.h>
main()
{
	
	char sample[20]="hello";
	fork();//o/p:hellohello
	fork();//hellohellohellohello
	printf("%s",sample);
	
}
