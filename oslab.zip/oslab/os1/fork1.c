#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>
#include<sys/types.h>
main()
{
	printf("Process id= %d",getpid());
	char sample[20]="hello";
	fork();
        printf("%s\n",sample);
	//Process id= 11368hello
	//Process id= 11368hello
}

