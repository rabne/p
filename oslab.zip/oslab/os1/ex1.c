#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>
#include<sys/types.h>
int main(){
	int id,a;
	id=fork();
	if(id>0){
	for(a=0;a<3;a++)
	printf("hello I'M parent with an ID:%d\n",getpid());
	printf("process created with ID:%d\n",id);
	}
	else if(id==0){
	char *args[]={"./sample",NULL};
	execv(args[0],args);
	printf("child process");
	}
	else{
	printf("process is not created");
	}
}
	
