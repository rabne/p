import java.util.*;
import java.io.*;
public class FIFO{
	public static void main(String args[]){
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the no of frames:");
		int a=sc.nextInt();
		System.out.println("Enter the no of elements in the sequence");
		int n=sc.nextInt();
		System.out.println("Enter the sequence order");
		String arr[]=new String[n];
		for(int i=0;i<n;i++){
			arr[i]=sc.next();
		}
		String[] frame=new String[a];
		for(int i=0;i<a;i++){
			frame[i]="-1";
		}
		int[] entry=new int[a];
		int hit=0;int miss=0;
		int in=0;
		for(int k=0;k < n;k++){
			 int flag=linearSearch(frame,a,arr[k]);
			 if(flag != -1){
			 	hit++;
			 }
			 else{
			 	int min=Integer.MAX_VALUE;
			 	int index=0;
			 	for(int j=0;j<a;j++){
			 		if(min > entry[j]){
			 			min=entry[j];
			 			index=j;
			 		}
			 	}
			 	frame[index]=arr[k];
			 	entry[index]=k+1;
			 	miss++;
			 }
		}
		System.out.println("HIT:"+hit+" "+"MISS:"+miss);
	}
	public static int linearSearch(String[] frame,int n,String m){
		int count=0;
		boolean dum;
		for(int i=0;i< n;i++){
			dum=frame[i].equals(m);
			if(dum){
				return i;
			}
		}
		return -1;
	}
	
}
