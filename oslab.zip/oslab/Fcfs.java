import java.util.*;
public class Fcfs{
	public static void main(String args[]){
		Queuee qu=new Queuee();
		qu.userQueue();
	}
}
class Queuee{
	Queue<Node> que=new LinkedList<Node>();
	public void userQueue(){
		Scanner sc=new Scanner(System.in);
		System.out.println("ENter no of processes:");
		int n=sc.nextInt();
		Process head=null;
		for(int i=0; i< n ;i++){
			System.out.println("ENter process "+(i+1)+" Arrival time and burst time");
			int arr=sc.nextInt();
			int burst=sc.nextInt();
			Node obj=new Node(arr,burst);
			que.offer(obj);
		}
		while(que.isEmpty() == false){
			Node first=que.poll();
			Process pobj=new Process();
			head=pobj.insert(head,first);
		}
		cpu.find(head,n);
		Process.traversal(head);
	}
}
class Node{
	int arrival;
	int burst;
	int complete;
	int turnaround;
	int waiting;
	Node next;
	Node(int arrival,int burst){
		this.arrival=arrival;
		this.burst=burst;
	}
}
class Process{
	Node pros;
	Process next;
	Process(Node pros)
	{
		this.pros=pros;
	}
	Process()
	{
	
	}
	public static Process insert(Process head,Node p){
		Process curr=head;
		Process temp=new Process(p);
		if(curr == null)
		{	
			return temp;
		}
		if(curr.next == null)
		{	
			curr.next=temp;
			return head;
		}
		while(curr.next != null){
			curr=curr.next;
		}
		curr.next=temp;
		return head;
	}
	public static void traversal(Process head){
		Process curr=head;
		System.out.println("process | Arrival | Burst | Completion Time | Turn Around | Waiting |");
		int i=1;
		while(curr != null){
			System.out.println(i+"          "+curr.pros.arrival+"         "+curr.pros.burst+"            "+curr.pros.complete+"          "+curr.pros.turnaround+"           "+curr.pros.waiting );
			curr=curr.next;
			i++;
		}
	}	
}
class cpu{
	
	public static void find(Process head,int n){
		int idel=0;
		int cputime=0;
		float avgturnaround=0;
		float avgwaiting=0;
		while(head != null){
			if(head.pros.arrival > cputime){
				idel+=(head.pros.arrival - idel); 
				cputime=head.pros.arrival;
			}
			else{
				cputime+=head.pros.burst;
				head.pros.complete=cputime;
				head.pros.turnaround=head.pros.complete-head.pros.arrival;
				head.pros.waiting=head.pros.turnaround-head.pros.burst;
				avgturnaround+=(float)head.pros.turnaround;
				avgwaiting+=(float)head.pros.waiting;
				head=head.next;
			}	
			
		}
		System.out.println("Average Turn Around time:"+avgturnaround/n);
		System.out.println("Average Waiting time:"+avgwaiting/n);
	}
	
}
