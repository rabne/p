import java.util.*;
public class FirstFit{
	public static void main(String args[]){
		Scanner sc=new Scanner(System.in);
		int n;
		System.out.println("Enter the no of process:");
		n=sc.nextInt();
		System.out.println("Enter the memory required of each process:");
		int[] arr=new int[n];
		for(int i=0;i< n;i++){
			arr[i]=sc.nextInt();
		}
		System.out.println("Enter the no of partitions");
		int m=sc.nextInt();
		int[] partition=new int[m];
		System.out.println("ENter the free space of each partition:");
		for(int i=0;i< m;i++){
			partition[i]=sc.nextInt();
		}
		int[] best=new int[m];
		for(int i=0;i<n;i++){
			int index=bestFit(arr[i],partition);
			System.out.print(index+" ");
			if(index != -1){
				best[index]=i+1;
				partition[index]=-1;
			}
		}
		System.out.println(Arrays.toString(best));
		System.out.println("----------First Fit----------");
		for(int i=0;i<m;i++){
			if(best[i] != 0)
				System.out.println("p"+best[i]);
			else
				System.out.println("--");
		}
	}
	public static int bestFit(int p,int[] array){
		int index=-1;
		for(int i=0;i< array.length;i++){
			if(p <= array[i] && array[i] != -1){
				return i;
			}
		}
		return index;
	}
}
